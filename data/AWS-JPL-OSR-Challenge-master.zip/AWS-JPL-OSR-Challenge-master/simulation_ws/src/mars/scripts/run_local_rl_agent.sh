#!/usr/bin/env bash

set -ex


python3 -m markov.rover_agent
